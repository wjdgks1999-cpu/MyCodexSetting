# billion-context integration

Experimental optional integration for Windows Paseo chat. Prepare a host runtime, then enable codex-bili for new chats. Existing chats retain their provider.

MyCodexSetting uses [billion-context](https://github.com/ranxianglei/billion-context) and its [acp-kernel](https://github.com/ranxianglei/acp-kernel). See THIRD_PARTY_NOTICES.md.

Sessions, logs, npm cache and exports may contain conversation content. Keep the runtime private. Bili also stores CA/cache/state under its normal XDG directories and Codex overlays beside the original Codex home. Authentication must remain linked; never copy auth into an artifact. No automatic cleanup or uninstall deletes user data.
