# MyCodexSetting 사용 설명서

MyCodexSetting은 Codex가 프로젝트의 작업 지침과 요구사항을 찾고, 새 세션에서 작업을 이어갈 수 있도록 문서 탐색과 인계 흐름을 설치합니다.

## 준비사항

| 항목 | 준비할 내용 |
|---|---|
| 요구사항 | 대상 프로젝트 내부의 UTF-8 Markdown 또는 텍스트 PRD/GDD |
| Python | 3.11 이상. 실행 라이브러리는 Python 표준 라이브러리만 사용 |
| Codex | 대상 폴더에서 파일과 스킬을 사용할 수 있는 환경 |
| Superpowers | 실제 사용할 수 있도록 미리 준비. 이 도구가 설치하지 않음 |
| 대상 폴더 | PRD만 있어도 가능. 기존 프로젝트도 파일을 보존하며 적용 |

이 README와 [버전별 변경 이력](CHANGELOG.md)은 MyCodexSetting의 배포 문서입니다. 설치 대상에는 포함되지 않으므로 프로젝트에 적용한 뒤 배포 사본에서 삭제할 수 있습니다. 대상 프로젝트의 기존 README는 설치 시 보존합니다.

## 파일과 역할

| 대상 프로젝트의 파일 | 역할 | 갱신 시점 |
|---|---|---|
| `AGENTS.md` | 짧은 작업 지침과 문서 탐색 안내 | 확인된 명령·작업 규칙 변경 |
| `.codex/config.toml` | 프로젝트의 Codex 기본 설정; 기존 파일은 보존 | 최초 설치 시 없을 때 생성; 이후 사용자가 조정 |
| `.context/index.md` | 원본 문서의 경로·용도와 설정 상태 | 초기화, 문서 이동, 작업 전환 |
| 기존 PRD/GDD·설계·운영 문서 | 해당 정보의 원본 | 해당 요구사항·설계·사실 변경 |
| `.context/decisions.md` | 기존 원본이 없는 확인된 장기 결정 | 필요할 때 처음 생성 |
| `.context/handoffs/*.md` | 작성 시점의 상태·근거·다음 행동 | 명시적 Handoff 호출 |
| `.mycodex/` | 실행 도구·정책·템플릿·설치 목록 | 최초 설치; 자동 업데이트 없음 |
| `.agents/skills/project-init/` | 프로젝트 설정 조사 스킬 | 설치 버전 기준 |
| `.agents/skills/session-handoff/` | 세션 인계 스킬 | 설치 버전 기준 |
| `.agents/skills/human-html/` | 사용자가 지정한 주제를 HTML로 설명하는 스킬·저장 도구 | 설치 버전 기준 |
| `.agents/skills/context-compression/` | 명시적인 Paseo 압축 연동 관리 스킬 | 요청 시 별도 준비·연결 |
| `.human-docs/` | 일반 개발 탐색에서 제외하는 사람용 HTML 산출물 | 명시적 HTML 생성·수정 요청 |

`project.md`와 빈 지식 문서는 기본 생성하지 않습니다. 긴 설명은 기존 원본을 우선하고 필요한 주제별 문서만 추가합니다. Superpowers가 관리하는 설계·계획·진행 원장을 별도 진행 문서로 복제하지 않습니다.

## 1. 설치 변경안 확인과 적용

MyCodexSetting 폴더에서 실행합니다. 아래 대상 경로는 예시이므로 실제 경로로 바꾸세요. 공백·한글이 있으면 따옴표로 감쌉니다.

```powershell
python kit/mycodex.py init --target "C:/work/나의 프로젝트" --requirements PRD.md
python kit/mycodex.py init --target "C:/work/나의 프로젝트" --requirements PRD.md --apply
```

첫 명령은 파일을 쓰지 않는 dry-run입니다. 두 번째 명령이 설치합니다. 요구사항이 여러 개면 `--requirements docs/GDD.md`처럼 옵션을 반복합니다. 요구사항 경로는 대상 프로젝트 루트 기준입니다.

새 설치는 `AGENTS.md`와 `.context/index.md`만 프로젝트 문서로 만들고 index 상태를 `needs-review`로 둡니다. 기존 AGENTS/index는 보존합니다. Git 저장소가 없어도 설치할 수 있으며 Git을 대신 초기화하지 않습니다.

프로젝트 설정 `.codex/config.toml`도 파일이 없을 때 함께 생성합니다. 기본값의 원본은 `kit/templates/config.toml`이며, 이 저장소에서 사용하던 모델·추론 강도·검색·권한·기억·에이전트 설정을 담았습니다. 대상에 기존 파일이 있으면 그대로 보존합니다. 설치 후 설정을 바꿔도 재설치가 덮어쓰거나 구조 검증이 자산 충돌로 보고하지 않습니다.

설정 템플릿은 `.mycodex/templates/config.toml`에도 설치되어 무결성 검증을 받습니다. 실제 프로젝트 설정은 사용자가 관리합니다. [Codex 프로젝트 설정 공식 문서](https://learn.chatgpt.com/docs/config-file/config-basic)에 따라 프로젝트를 신뢰한 경우 프로젝트 설정이 로드되며, 파일 생성과 현재 세션의 설정 적용은 구분해야 합니다.

## 2. 프로젝트 설정 조사

대상 프로젝트를 Codex에서 열고 명시적으로 호출합니다.

```text
$project-init PRD.md를 기준으로 프로젝트 세팅을 초기화해 주세요.
```

스킬은 기존 지침·요구사항·코드·문서를 조사하고 Superpowers의 실제 사용 가능 여부를 확인합니다. 필요한 원본을 index에 연결하고, 적용되는 루트 지침 파일에 index 탐색 규칙을 반영합니다. 내용이 있는 `AGENTS.override.md`가 있으면 그 파일을 사용합니다. 코드가 없는 경우 기술 스택과 빌드·테스트 명령을 추정하지 않습니다.

조사와 구조 검증이 끝나면 index는 `ready`가 됩니다. **ready는 세팅 조사 완료이며 제품 개발 완료나 애플리케이션 테스트 통과가 아닙니다.** 스킬이 목록에 없으면 새 세션에서 `.agents/skills/` 설치 경로와 검색 여부를 확인하세요.

## 3. 구조 검증

대상 프로젝트 루트에서 실행합니다.

```powershell
python .mycodex/mycodex.py validate --target .
python .mycodex/mycodex.py validate --target . --strict --json
```

| 종료 코드 | 의미 |
|---|---|
| 0 | 검증 오류 없음. 기본 모드에서는 경고가 있을 수 있음 |
| 1 | 구조·경로·설치 충돌 등의 검증 오류. strict에서는 경고도 포함 |
| 2 | 잘못된 CLI 인자 또는 I/O로 실행 불가 |

검증은 읽기 전용입니다. 설치 파일 해시, 명시적 스킬 정책, index와 등록된 파일 경로, 필수 Handoff 항목을 확인합니다. 출력은 진단 코드·경로·조치이며 문서 본문을 출력하지 않습니다. 사라진 임시 원장은 경고로 보고하며 완료를 추정하지 않습니다.

## 4. 개발과 세션 인계

제품 설계·계획·구현은 준비된 Superpowers 절차로 진행합니다. Git이 없는 폴더라면 Git 기반 구현·복구를 사용하기 전에 해당 개발 작업에서 준비합니다. 문서 생성·이동과 작업 전환 시 index의 해당 경로를 갱신합니다.

인계할 때 명시적으로 호출합니다.

```text
$session-handoff 현재 작업과 검증 결과를 정리하고 다음 세션에서 이어갈 문서를 만들어 주세요.
```

스킬은 지속적인 지식을 적절한 원본에 반영하고, 날짜가 있는 Handoff와 최신 포인터를 기록합니다. 일반 상태 질문이나 종료 인사만으로 실행하지 않습니다. 기록 실패 시 남은 초안·스냅샷·장기 지식 반영 상태를 구분해 보고합니다.

## 5. 새 세션에서 이어가기

대상 프로젝트를 열고 이어서 할 작업을 요청합니다. Codex는 AGENTS → index → 관련 Handoff·계획·원본을 찾아 현재 파일/Git 상태와 대조합니다. 과거 테스트 통과는 현재 변경 이후의 결과로 재사용하지 않습니다. 모든 과거 세션 문서를 한꺼번에 읽도록 요구하지 않습니다.

## 사람이 읽는 HTML 문서

설치한 프로젝트에서 스킬을 명시적으로 호출하고, 무엇을 문서로 만들지 직접 적습니다.

```text
$human-html
현재 프로젝트에서 개발하고 있는 앱 서비스의 구조를 html 문서로 정리해줘.
```

스킬은 필요한 원본만 조사하고 설명·표·도식을 활용한 독립 HTML을 만듭니다. 주제가 없으면 먼저 질문합니다. CSS와 도식을 내부에 넣어 브라우저에서 오프라인으로 읽을 수 있으며, 생성 결과에는 파일 링크와 실제 검증 결과를 보고합니다.

문서는 처음 생성할 때 준비하는 `.human-docs/`에 고유한 파일명으로 저장합니다. 폴더 내부의 `.gitignore`와 `.ignore`는 Git과 ignore 규칙을 따르는 검색에서 본문을 제외합니다. Git이 없는 폴더의 ripgrep 검색에도 `.ignore`가 적용됩니다. 기존 루트 제외 파일은 변경하지 않습니다. 같은 위치에 맞춤형 제외 파일이 있으면 보존하고 충돌을 보고합니다.

일반 개발에서는 이 폴더를 읽기·검색 대상에서 제외하며, 인덱스나 인계의 원본으로 연결하지 않습니다. `--no-ignore` 검색에서도 `-g '!.human-docs/**'`를 지정합니다. 명시적인 HTML 생성·수정·검증 때는 해당 파일에 접근할 수 있습니다. **일반 탐색 제외이며 파일 접근 차단이나 생성 시 토큰 사용량 0을 보장하지 않습니다.**

저장 도구는 UTF-8 stdin을 받아 경로만 반환합니다. 직접 점검하려면 다음처럼 실행합니다. 이 검사는 기본 HTML 구조만 확인하며, 내용의 사실성·화면 가독성은 별도 확인 대상입니다.

```powershell
python .agents/skills/human-html/scripts/save_html.py --target . --check .human-docs/생성된-파일명.html
```

## 충돌과 기존 파일

기존 요구사항·코드·설정과 AGENTS는 설치 스크립트가 덮어쓰지 않습니다. 같은 입력의 설치 재실행은 동일 자산을 건너뜁니다. 다른 배포 자산이 있으면 전체 사전 검사에서 멈추며 강제 교체·자동 업데이트 옵션은 없습니다. 다른 버전으로의 이전은 별도 검토가 필요합니다. 새 배포본을 받아도 기존 프로젝트의 AGENTS와 인덱스는 자동으로 갱신되지 않습니다.

설치 도중 I/O가 실패하면 부분 설치가 남을 수 있습니다. 원인을 해결한 뒤 같은 원본 kit으로 dry-run을 다시 확인하세요. Handoff 포인터 교체가 실패해 연결되지 않은 스냅샷이 남으면 보고된 경로를 확인합니다. 기존 이력이나 사용자 파일을 일괄 삭제하지 마세요.

Handoff 도구의 동시 기록은 index 잠금으로 조정합니다. 잠금에 협력하지 않는 외부 편집기의 모든 경쟁까지 보장하지는 않습니다. `.context/.index.lock`이 남으면 다른 기록 작업이 끝났는지 확인한 후 처리하세요.

## 설정 범위와 검증 한계

사용자 전역 설정·기억과 기존 `.codex/config.toml`은 변경하지 않습니다. 대상 설정이 없을 때만 배포 템플릿으로 생성하며, 설치 후 모델·추론 강도·권한·네트워크·기억 설정은 대상 프로젝트의 `.codex/config.toml`에서 조정할 수 있습니다. 현재 저장소의 개발용 설정을 이후 설치 때마다 읽어 복사하지 않으므로, 배포 기본값을 바꾸려면 `kit/templates/config.toml`을 수정합니다. 비밀 파일과 원문 전문은 프로젝트 기억에 복사하지 않습니다.

구조 검증이 통과해도 문서의 내용과 최신성은 현재 원본과 대조해야 합니다. 애플리케이션 동작은 프로젝트에서 별도로 검증합니다. 토큰 절감률은 보장하지 않습니다. 선택 압축 기능을 연결하지 않으면 기존 문서 탐색·인계 흐름으로 동작합니다.

## Paseo 문맥 압축 — 실험 기능

MyCodexSetting은 [billion-context](https://github.com/ranxianglei/billion-context)와 그 내장 [acp-kernel](https://github.com/ranxianglei/acp-kernel)을 선택적으로 사용합니다. 패키지를 ZIP에 내장하지 않고 **0.1.213으로 고정된 npm lock**으로 호스트 runtime에 설치합니다. [출처와 전체 라이선스 고지](kit/integrations/billion-context/THIRD_PARTY_NOTICES.md)를 확인하세요. upstream LICENSE에는 MIT 본문 외 제품 출처 표시 조건도 있습니다.

실측 조합은 **Windows / Paseo 0.15.4 / Codex 0.167.0 / Bili 0.1.213 / Node 26.13.0 / gpt-6.1-sol low**입니다. 실제 Paseo CLI/SDK 경로에서 모델 요청·압축·복원·MCP 병합·합성 개발·인계·기존 Codex 재개를 확인했습니다. UI 스킬 목록, 승인 검토 역할의 격리, web/rules/hooks/memory 전체, Codex 기본 compaction과의 동시 발생, 포트 충돌·강제 장애·재연결 전체는 미검증입니다. 다른 OS·버전·모델로 결과를 일반화하지 않습니다.

기본 `init`/`validate`에는 Node와 네트워크가 필요 없습니다. 압축 기능만 Node 20+와 npm, 실제 Paseo가 사용하는 Codex 실행 파일이 필요합니다. Windows 기본 runtime은 `%LOCALAPPDATA%/MyCodexSetting/billion-context/0.1.213/`이며 프로젝트와 별도입니다. Paseo의 `provider diagnostic codex`로 선택 경로를 확인하세요. 다르면 `MYCODEX_CODEX_EXE`를 그 경로로 설정한 프로세스에서 준비합니다. 설치된 Codex는 버전 실행 파일로 고정되므로 업데이트 뒤 자동 전환되지 않습니다.

설치한 프로젝트 루트에서 실행합니다. 각 변경 명령은 먼저 `--apply` 없이 변경안을 확인할 수 있습니다. `--runtime`과 `--paseo-home`으로 시험용 절대 경로를 지정할 수 있습니다.

```powershell
python .mycodex/mycodex.py compression doctor --target . --json
python .mycodex/mycodex.py compression prepare --target .
python .mycodex/mycodex.py compression prepare --target . --apply
python .mycodex/mycodex.py compression paseo-enable --target .
python .mycodex/mycodex.py compression paseo-enable --target . --apply
```

Paseo에서 **Codex 문맥 압축**을 선택해 새 chat을 시작합니다. 기존 Codex 제공자·기존 chat은 유지됩니다. `saved_not_active`는 설정 파일만 저장한 상태이며 Paseo 설정 reload 후 새 chat을 시작해야 합니다. 자동 데몬 재시작이나 기존 chat 강제 이동은 하지 않습니다. `$context-compression`으로 진단·준비·연결·해제를 요청할 수도 있습니다.

`doctor`는 설치, 제공자 등록, 프로토콜 검증, 모델 경유, 압축 관찰을 구분합니다. 관찰 증거가 없는 항목은 `unknown`이며 설치 성공이나 MCP 노출만으로 압축이 작동한다고 판정하지 않습니다. 기존 runtime이나 동명 제공자가 다르면 보존하고 충돌로 중단합니다. 설치 중단 runtime은 자동 삭제·덮어쓰지 않으며 검토 후 새 빈 경로에서 준비할 수 있습니다.

요약을 명시적으로 추출할 때는 `compression export --target . --session <Codex thread UUID> --apply`를 사용합니다. runtime의 `exports/`에 고유 JSON을 만들고 경로만 출력합니다. 첫 버전은 활성 요약만 제공하며 원문은 내보내지 않습니다. 요약의 사실·완료·승인을 현재 원본과 재확인한 뒤 `$session-handoff`로 인계하세요. export는 index나 최신 인계로 자동 등록되지 않습니다.

```powershell
python .mycodex/mycodex.py compression paseo-disable --target .
python .mycodex/mycodex.py compression paseo-disable --target . --apply
```

해제 후 새 chat에서 기존 Codex를 선택합니다. 도구 소유이며 수정되지 않은 제공자만 제거하고, 실행 중인 chat·세션·export·다른 프록시를 삭제하지 않습니다. 현재 사용자 Paseo에 압축 기능을 연결하는 작업은 이 배포본을 받는 것과 별개입니다.

자동 업데이트·자동 업데이트 재시작·advisory 확인·본문 덤프는 꺼져 있습니다. 외부 요약 서버를 기본 설정하지 않습니다. bridge는 부모 PATH·환경과 전역 Codex 설정을 변경하지 않고 기존 proxy/CA를 우회하지 않습니다. 별도의 `CODEX_CA_CERTIFICATE`가 설정된 환경은 검증되지 않아 실행 전 중단합니다. runtime의 세션·로그·export는 대화 내용이 들어갈 수 있으므로 비공개로 보관하세요. Bili의 CA·캐시·상태는 기본 XDG 위치에도 생기고 Codex overlay는 원래 Codex home 옆에 생깁니다. 모든 데이터가 runtime에 격리되는 것은 아닙니다. OS 인증서 저장소는 변경하지 않습니다.

## 참고 문서

- [Codex AGENTS.md 공식 문서](https://learn.chatgpt.com/docs/agent-configuration/agents-md)
- [Codex Skills 공식 문서](https://learn.chatgpt.com/docs/build-skills)
